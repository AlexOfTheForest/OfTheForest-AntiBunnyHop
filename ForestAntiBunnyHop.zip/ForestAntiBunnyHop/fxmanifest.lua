fx_version 'cerulean'
game 'gta5'

author 'AlexOfTheForest'
description 'OfTheForest antibunnyhop'
version '1.0.0'

client_scripts {
    'client.lua'
}
